from setuptools import setup, find_packages

version = '0.0.1'


setup(
    name="SFA",
    version="0.1",
    packages=find_packages(),
    install_requires=['torch','pprint'],
)
